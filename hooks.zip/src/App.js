import logo from './logo.svg';
import './App.css';
import Classcount from './components/Classcount';
import HookCounter from './components/HookCounter';
import HookCounterTwo from './components/HookCounterTwo';
import HookCounterThree from './components/HookCounterThree';
import HookCounterFour from './components/HookCounterFour';
import EffectCounterOne from './components/EffectCounterOne';
import HookMouse from './components/HookMouse';
import MouseContainer from './components/MouseContainer';
import IntervalHookCounter from './components/IntervalHookCounter';
import DataFetching from './components/DataFetching';
import React from 'react';
import UseContextC from './components/UseContextC';
import CounterOne from './components/UseReducer/CounterOne';
import CounterTwo from './components/UseReducer/CounterTwo';

export const UserContext = React.createContext()
export const ChannelContext = React.createContext()

function App() {
  return (
    <div className="App">
      <CounterTwo />
      {/* <CounterOne /> */}
      {/* <UserContext.Provider value={'Arsh'}>
        <ChannelContext.Provider value={'AITECH'}>
          <UseContextC />
        </ChannelContext.Provider>
      </UserContext.Provider> */}
      {/* <DataFetching /> */}
      {/* <IntervalHookCounter /> */}
      {/* <MouseContainer /> */}
      {/* <HookMouse /> */}
      {/* <EffectCounterOne /> */}
      {/* <HookCounterFour /> */}
      {/* <HookCounterThree /> */}
      {/* <HookCounterTwo /> */}
      {/* <HookCounter /> */}
      {/* <Classcount /> */}
    </div>
  );
}

export default App;
