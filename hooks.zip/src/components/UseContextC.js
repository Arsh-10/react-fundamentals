import React from 'react'
import USeContextD from './USeContextD'


function UseContextC() {
  return (
    <div>
      <USeContextD />
    </div>
  )
}

export default UseContextC
