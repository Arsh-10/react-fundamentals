import React, {useContext} from 'react'
// import UseContextE from './UseContextE'
import { UserContext, ChannelContext } from '../App'

function USeContextD() {
    const user = useContext(UserContext)
    const channel = useContext(ChannelContext)
  return (
    <div>
      {user} - {channel}
    </div>
  )
}

export default USeContextD
