import logo from './logo.svg';
import './App.css';
import ListPosts from './components/ListPosts';
import PostForm from './components/PostForm';

function App() {
  return (
    <div className="App">
      <PostForm />
      {/* <ListPosts /> */}
    </div>
  );
}

export default App;
