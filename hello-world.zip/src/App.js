import logo from './logo.svg';
import './App.css';
import Greet  from './components/Greet';
import Welcome from './components/Welcome';
import Message from './components/Message';
import Counter from './components/Counter';
import FunctionClicks from './components/FunctionClicks';
import ClassClick from './components/ClassClick';
import EventBind from './components/EventBind';
import ParentComponent from './components/ParentComponent';
import UserGreeting from './components/UserGreeting';
import NameList from './components/NameList';
import StyleSheet from './components/StyleSheet';
import Form from './components/Form';


function App() {
  return (

  <div className="App" primary={false}>

    <Form />
    
    {/* <StyleSheet /> */}

    {/* <NameList /> */}
    {/* <UserGreeting /> */}
    {/* <ParentComponent /> */}
      {/* <EventBind /> */}
      {/* <ClassClick /> */}
      {/* <FunctionClicks />
      <Counter /> */}
     
      {/* <Message /> */}
      {/* <Greet name="Arsh" hero="Batman" >
        <p>Hello I am child</p>
      </Greet>
      <Greet name="Haseeb" hero="Flash" >
        <button>check me out!</button>
      </Greet>
      <Greet name="Asad" hero="Wonder Women" />
      <Welcome name="Arsh" hero="Batman" />
      <Welcome name="Haseeb" hero="Flash" />
      <Welcome name="Asad" hero="Wonder Women" /> */}
    </div>
  );
}

export default App;
