import React, { Component, components } from 'react'

class Welcome extends Component {
    render () {
        return <h1>Hello {this.props.name} AKA {this.props.hero} </h1>
    }
}

export default Welcome