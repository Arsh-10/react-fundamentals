import React, { Component } from 'react'

class Form extends Component {

    constructor(props) {
      super(props)
    
      this.state = {
         userName: '',
         comments: ''
      }
    }
    
    handleChange = (event) => {
        this.setState({
            userName: event.target.value
        })
    }

    handleCommentChange = (event) => {
        this.setState({
            comments: event.target.value
        })
    }

    handleSubmit = (event) => {
        alert(`${this.state.userName} ${this.state.comments}`)
        event.preventDefault()
    }

  render() {
    const {userName, comments} = this.state
    return (
        <form onSubmit={this.handleSubmit}>
            <div>
                <label>Username</label>
                <input type='text' value={userName} onChange={this.handleChange} />
            </div>
            <div>
                <label>Comments</label>
                <textarea value={comments} onChange={this.handleCommentChange}></textarea>
            </div>
            <button type='submit'>Submit</button>
        </form>
    )
  }
}

export default Form
