import React, { Component } from 'react'

class UserGreeting extends Component {
    constructor(props) {
      super(props)
    
      this.state = {
         isLoggedIn: true
      }
    }
    
  render() {
    return this.state.isLoggedIn?  (
        <div>Welcome Arsh!</div>
    ) : (
        <div>Welcome Guest!</div>
    )

    // let message
    // if (this.state.isLoggedIn) {
    //     message = <div>Welcome Arsh!</div>
    // } else {
    //     message = <div>Welcome Guest!</div>
    // }

    // return message
    // if (this.state.isLoggedIn) {
    //     return <div>Welcome Arsh!</div>
    // } else {
    //     return <div>Welcome Guest!</div>
    // }
    // return (
    //   <div>
    //     Welcome Arsh!
    //   </div>
    // )
  }
}

export default UserGreeting
