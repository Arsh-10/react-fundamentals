import React from 'react'
import './mySTyle.css'

function StyleSheet(props) {
    let className = props.primary ? 'primary' : ''
  return (
    <div>
      <h1 className={`${className} fontt `} >Styling</h1>
    </div>
  )
}

export default StyleSheet